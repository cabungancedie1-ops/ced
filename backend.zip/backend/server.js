const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const cors = require('cors');

const app = express();

// =======================
// ✅ MIDDLEWARE
// =======================

app.use(express.json());

app.use(cors({
  origin: true,
  credentials: true
}));

app.use(session({
  secret: 'blysseful_secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false
  }
}));

// =======================
// ✅ MONGODB CONNECTION
// =======================

mongoose.connect(
  'mongodb+srv://admin:admin123@cluster0.rcorxhc.mongodb.net/blyssefulDB?retryWrites=true&w=majority'
)

.then(() => console.log('✅ MongoDB Connected'))

.catch(err => console.log(err));

// =======================
// ✅ MODELS
// =======================

const User = mongoose.model('User', new mongoose.Schema({

  full_name: String,

  username: {
    type: String,
    unique: true
  },

  email: {
    type: String,
    unique: true
  },

  password: String

}));

const Order = mongoose.model('Order', new mongoose.Schema({

  user_id: String,
  username: String,
  product_name: String,
  price: Number,
  quantity: Number

}));

const Message = mongoose.model('Message', new mongoose.Schema({

  name: String,
  email: String,
  message: String

}));

// =======================
// 🔐 SIGNUP
// =======================

app.post('/signup', async (req, res) => {

  try {

    const {
      full_name,
      username,
      email,
      password,
      confirm_password
    } = req.body;

    if(password !== confirm_password){

      return res.json({
        success: false,
        message: 'Passwords do not match'
      });

    }

    const existingUser = await User.findOne({
      $or: [
        { username },
        { email }
      ]
    });

    if(existingUser){

      return res.json({
        success: false,
        message: 'Username or email already exists'
      });

    }

    const hashedPassword = await bcrypt.hash(password, 10);

    await User.create({

      full_name,
      username,
      email,
      password: hashedPassword

    });

    res.json({
      success: true,
      message: 'Signup successful'
    });

  } catch(err){

    console.log(err);

    res.json({
      success: false,
      message: 'Server error'
    });

  }

});

// =======================
// 🔐 LOGIN
// =======================

app.post('/login', async (req, res) => {

  try {

    const { username, password } = req.body;

    const user = await User.findOne({
      $or: [
        { username },
        { email: username }
      ]
    });

    if(!user){

      return res.json({
        success: false,
        message: 'User not found'
      });

    }

    const match = await bcrypt.compare(password, user.password);

    if(!match){

      return res.json({
        success: false,
        message: 'Wrong password'
      });

    }

    req.session.user = user;

    res.json({

      success: true,
      username: user.username,
      full_name: user.full_name

    });

  } catch(err){

    console.log(err);

    res.json({
      success: false,
      message: 'Server error'
    });

  }

});

// =======================
// 🛒 ORDER
// =======================

app.post('/order', async (req, res) => {

  try {

    if(!req.session.user){

      return res.json({
        success: false,
        message: 'Login first'
      });

    }

    const { cart } = req.body;

    for(const item of cart){

      await Order.create({

        user_id: req.session.user._id,
        username: req.session.user.username,
        product_name: item.name,
        price: item.price,
        quantity: item.quantity

      });

    }

    res.json({
      success: true,
      message: 'Order saved'
    });

  } catch(err){

    console.log(err);

    res.json({
      success: false,
      message: 'Server error'
    });

  }

});

// =======================
// 📩 CONTACT
// =======================

app.post('/contact', async (req, res) => {

  try {

    const { name, email, message } = req.body;

    await Message.create({
      name,
      email,
      message
    });

    res.json({
      success: true,
      message: 'Message sent'
    });

  } catch(err){

    console.log(err);

    res.json({
      success: false,
      message: 'Server error'
    });

  }

});

// =======================
// 👥 VIEW USERS
// =======================

app.get('/users', async (req, res) => {

  const users = await User.find();

  res.json(users);

});

// =======================
// 🚀 START SERVER
// =======================

app.listen(3000, () => {
  console.log('🚀 Server running on port 3000');
});